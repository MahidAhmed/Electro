<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index(){
        return view('front-end.admin.category.addcategory');
    }
    public function savecategory(Request $request){
        $category=new Category();
        $category->category_name=$request->category_name;
        $category->cat_desc=$request->cat_desc;
        $category->pub_status=$request->pub_status;
        $category->save();
        return redirect('/category/add-category')->with('message','Category Saved Successfully');
    }
    public function managecategory(){
        $categories=Category::all();
        return view('front-end.admin.category.managecategory',[
            'categories'=>$categories
        ]);
    }
    public function unpublishedcategory($id){
            $category=Category::find($id);
            $category->pub_status=0;
            $category->save();
            return redirect('/category/manage-category')->with('message','Category Unpublished successfully');
    }
    public function publishedcategory($id){
        $category=Category::find($id);
        $category->pub_status=1;
        $category->save();
        return redirect('/category/manage-category')->with('message','Category published successfully');
    }
    public function editcategory($id){
        $category=Category::find($id);

        return view('front-end.admin.category.edit-category',[
            'category'=>$category]);
    }
    public  function  updatecategory(Request $request){
        $category=Category::find($request->category_id);
        $category->category_name=$request->category_name;
        $category->cat_desc=$request->cat_desc;
        $category->pub_status=$request->pub_status;
        $category->save();


        return redirect('/category/manage-category')->with('message','Category Updated successfully');
    }
}
