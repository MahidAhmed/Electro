<?php

namespace App\Http\Controllers;

use App\Brand;
use Illuminate\Http\Request;

class BrandController extends Controller
{
    public function index(){
        return view('front-end.admin.brand.addbrand');
    }
    public function addbrand(Request $request){
        $brand=new Brand();
        $brand->brand_name=$request->brand_name;
        $brand->brand_desc=$request->brand_desc;
        $brand->pub_status=$request->pub_status;
        $brand->save();
        return redirect('/brand/add-brand')->with('message','Brand Saved Successfully');
    }
    public function managebrand(){
        $brands=Brand::all();
        return view('front-end.admin.brand.managebrand',[
            'brands'=>$brands
        ]);
    }
    public function unpublishedbrand($id){
        $brand=Brand::find($id);
        $brand->pub_status=0;
        $brand->save();
        return redirect('/brand/manage-brand')->with('message','Brand Unpublished successfully');
    }
    public function publishedbrand($id){
        $brand=Brand::find($id);
        $brand->pub_status=1;
        $brand->save();
        return redirect('/brand/manage-brand')->with('message','Brand published successfully');
    }
}
