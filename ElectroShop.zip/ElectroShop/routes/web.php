<?php
Route::get('/',[
    'uses'=>'ElectroShopController@index',
    'as' => '/'
    ]);
Route::get('/about-us',[
    'uses'=>'ElectroShopController@about',
    'as' => 'about-us'
]);
Route::get('/contact-us',[
    'uses'=>'ElectroShopController@contact',
    'as' => 'contact-us'
]);
Route::get('/products',[
    'uses'=>'ElectroShopController@products',
    'as' => 'products'
]);
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/category/add-category',[
    'uses'=>'CategoryController@index',
    'as' => 'add-category'
]);
Route::post('/category/save',[
    'uses'=>'CategoryController@savecategory',
    'as' => 'new-category'
]);
Route::get('/category/manage-category',[
    'uses'=>'CategoryController@managecategory',
    'as' => 'manage-category'
]);
Route::get('/category/unpublished-category/{id}',[
    'uses'=>'CategoryController@unpublishedcategory',
    'as' => 'unpublished-category'
]);
Route::get('/category/published-category/{id}',[
    'uses'=>'CategoryController@publishedcategory',
    'as' => 'published-category'
]);
Route::get('/brand/add-brand',[
    'uses'=> 'BrandController@index',
    'as'=> 'add-brand'
]);
Route::post('/brand/new-brand',[
    'uses'=> 'BrandController@addbrand',
    'as'=> 'new-brand'
]);
Route::get('/brand/manage-brand',[
    'uses'=> 'BrandController@managebrand',
    'as'=> 'manage-brand'
]);

Route::get('/brand/unpublished-brand/{id}',[
    'uses'=>'BrandController@unpublishedbrand',
    'as' => 'unpublished-brand'
]);
Route::get('/brand/published-brand/{id}',[
    'uses'=>'BrandController@publishedbrand',
    'as' => 'published-brand'
]);
Route::get('/category/edit-category/{id}',[
    'uses'=> 'CategoryController@editcategory',
    'as'=>'edit-category'
]);
Route::post('/category/update',[
    'uses'=> 'CategoryController@updatecategory',
    'as'=>'update-category'
]);