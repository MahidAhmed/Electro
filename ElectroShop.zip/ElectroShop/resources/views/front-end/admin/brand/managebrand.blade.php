@extends('front-end.admin.master')
@section('body')
    <br>


    <div class="container py-5">


        <h2 class="text-center text-success">{{Session::get('message')}}</h2>

        <div class="row justify-content-center">
            <table class="table table-bordered">
                <thead class="text-center">
                <tr class="bg-success text-white">
                    <th scope="col">Sl No</th>
                    <th scope="col">Brand Name</th>
                    <th scope="col">Brand Description</th>
                    <th scope="col">Publication Status</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody class="text-center">
                @php($i=1)
                @foreach($brands as $brand)
                    <tr>

                        <td>{{$i++}}</td>
                        <td>{{$brand->brand_name}}</td>
                        <td>{{$brand->brand_desc}}</td>
                        <td>{{$brand->pub_status==1 ? 'Published' : 'Unpublished'}}</td>
                        <td>
                            @if($brand->pub_status==1)
                                <a href="{{route('unpublished-brand',['id'=>$brand->id])}}" class="btn btn-primary">
                                    <span class="fa fa-arrow-up"></span>

                                </a>
                            @else
                                <a href="{{route('published-brand',['id'=>$brand->id])}}" class="btn btn-warning">
                                    <span class="fa fa-arrow-down"></span>

                                </a>
                            @endif
                            <a href="" class="btn btn-success">
                                <span class="fa fa-edit"></span>

                            </a>
                            <a href="" class="btn btn-danger">
                                <span class="fa fa-trash"></span>

                            </a>
                        </td>


                    </tr>
                @endforeach
                </tbody>

            </table>

        </div>
    </div>

@endsection