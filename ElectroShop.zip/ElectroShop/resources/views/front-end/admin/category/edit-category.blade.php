@extends('front-end.admin.master')

@section('body')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">

                <div class="card">
                    <div class="card-header bg-light">
                        <h4 class="text-center text-success">Update Category</h4>

                    </div>
                    <div class="card-body">
                        <form action="{{route('update-category')}}" method="post">
                            {{csrf_field()}}
                            <div class="form-group row">
                                <label for="staticCatName" class="col-md-4 col-form-label">Category Name</label>
                                <div class="col-md-6">
                                    <input type="text" name="category_name" class="form-control" id="staticCatName"
                                           value="{{$category->category_name}}"     placeholder="Enter Category Name">
                                    <input type="hidden" name="category_id" class="form-control" id="staticCatName"
                                           value="{{$category->id}}"     placeholder="Enter Category Name">

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="staticCatDesc" class="col-md-4 col-form-label">Category Description</label>
                                <div class="col-md-6">
                                    <textarea class="form-control" name="cat_desc" id="staticCatDesc" placeholder="Enter Category Description">{{$category->cat_desc}}</textarea>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="pubstatus" class="col-md-4 col-form-label">Publication Status</label>
                                <div class="col-md-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="pub_status" {{$category->pub_status==1 ?'checked' : ''}} id="pubstatus" value="1">
                                        <label class="form-check-label" for="pubstatus">Published</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="pub_status" {{$category->pub_status==0 ?'checked' : ''}} id="pubstatus" value="0">
                                        <label class="form-check-label" for="pubstatus">Unpublished</label>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success">Update Category</button>

                            </div>
                        </form>
                    </div>

                </div>

            </div>

        </div>

    </div>
@endsection
