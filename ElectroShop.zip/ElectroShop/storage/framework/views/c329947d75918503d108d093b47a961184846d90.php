<?php $__env->startSection('body'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">

                <div class="card">
                    <div class="card-header bg-light">
                        <h4 class="text-center text-success">Update Category</h4>

                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('update-category')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group row">
                                <label for="staticCatName" class="col-md-4 col-form-label">Category Name</label>
                                <div class="col-md-6">
                                    <input type="text" name="category_name" class="form-control" id="staticCatName"
                                           value="<?php echo e($category->category_name); ?>"     placeholder="Enter Category Name">
                                    <input type="hidden" name="category_id" class="form-control" id="staticCatName"
                                           value="<?php echo e($category->id); ?>"     placeholder="Enter Category Name">

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="staticCatDesc" class="col-md-4 col-form-label">Category Description</label>
                                <div class="col-md-6">
                                    <textarea class="form-control" name="cat_desc" id="staticCatDesc" placeholder="Enter Category Description"><?php echo e($category->cat_desc); ?></textarea>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="pubstatus" class="col-md-4 col-form-label">Publication Status</label>
                                <div class="col-md-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="pub_status" <?php echo e($category->pub_status==1 ?'checked' : ''); ?> id="pubstatus" value="1">
                                        <label class="form-check-label" for="pubstatus">Published</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="pub_status" <?php echo e($category->pub_status==0 ?'checked' : ''); ?> id="pubstatus" value="0">
                                        <label class="form-check-label" for="pubstatus">Unpublished</label>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success">Update Category</button>

                            </div>
                        </form>
                    </div>

                </div>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ElectroShop\resources\views/front-end/admin/category/edit-category.blade.php ENDPATH**/ ?>