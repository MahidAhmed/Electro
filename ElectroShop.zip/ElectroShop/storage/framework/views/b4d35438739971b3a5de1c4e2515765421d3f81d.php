<?php $__env->startSection('body'); ?>

    <div class="container-fluid py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
<h4 class="text-center text-success"><?php echo e(Session::get('message')); ?></h4>
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-center text-success">Add Brand</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('new-brand')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group row">
                                <label for="catname" class="col-md-4 col-form-label font-weight-bold">Category Name</label>
                                <div class="col-md-8">
                                    <input type="text" name="brand_name" class="form-control" id="catname">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="catdesc" class="col-md-4 col-form-label font-weight-bold">Category Description</label>
                                <div class="col-md-8">
                                    <textarea name="brand_desc" id="catdesc" class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="staticEmail" class="col-md-4 col-form-label font-weight-bold">Publication Status</label>
                                <div class="col-md-8">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="pub_status" id="pubstatus" value="1">
                                        <label class="form-check-label" for="pubstatus">Published</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="pub_status" id="pubstatus" value="0">
                                        <label class="form-check-label" for="pubstatus">Unpublished</label>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" name="btn" class="btn btn-success">Add Brand</button>
                            </div>
                        </form>
                    </div>

                </div>

            </div>

        </div>

    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ElectroShop\resources\views/front-end/admin/brand/addbrand.blade.php ENDPATH**/ ?>