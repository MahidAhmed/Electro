<?php $__env->startSection('body'); ?>
    <br>


    <div class="container py-5">


        <h2 class="text-center text-success"><?php echo e(Session::get('message')); ?></h2>

        <div class="row justify-content-center">
            <table class="table table-bordered">
                <thead class="text-center">
                <tr class="bg-success text-white">
                    <th scope="col">Sl No</th>
                    <th scope="col">Brand Name</th>
                    <th scope="col">Brand Description</th>
                    <th scope="col">Publication Status</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody class="text-center">
                <?php ($i=1); ?>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($brand->brand_name); ?></td>
                        <td><?php echo e($brand->brand_desc); ?></td>
                        <td><?php echo e($brand->pub_status==1 ? 'Published' : 'Unpublished'); ?></td>
                        <td>
                            <?php if($brand->pub_status==1): ?>
                                <a href="<?php echo e(route('unpublished-brand',['id'=>$brand->id])); ?>" class="btn btn-primary">
                                    <span class="fa fa-arrow-up"></span>

                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('published-brand',['id'=>$brand->id])); ?>" class="btn btn-warning">
                                    <span class="fa fa-arrow-down"></span>

                                </a>
                            <?php endif; ?>
                            <a href="" class="btn btn-success">
                                <span class="fa fa-edit"></span>

                            </a>
                            <a href="" class="btn btn-danger">
                                <span class="fa fa-trash"></span>

                            </a>
                        </td>


                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ElectroShop\resources\views/front-end/admin/brand/managebrand.blade.php ENDPATH**/ ?>